names = ["Tony", "Jim", "Lee", "George"]
for name in names:
    print(name)
print(len(names))